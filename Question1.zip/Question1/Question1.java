/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question1;

/**
 *
 * @author wic180039
 */
public class Question1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Queue input=new Queue();
        Queue output=new Queue();
        input.enqueue('s');
        input.enqueue('t');
        input.enqueue('r');
        input.enqueue('u');
        input.enqueue('c');
        input.enqueue('t');
        System.out.print("Input Queue: [");
        int size=input.size;
        for(int i=0;i<size;i++){
            char c=input.dequeue();
            input.enqueue(c);
            System.out.print(c);
            if(i!=size-1)
                System.out.print(",");
        }
        System.out.println("]");
        
        reverse(input,output);
        System.out.print("Reverse Queue: [");
        int osize=output.size;
        for(int i=0;i<osize;i++){
            char c=output.dequeue();
            output.enqueue(c);
            System.out.print(c);
            if(i!=size-1)
                System.out.print(",");
        }
        System.out.println("]");
        
    }
    
    public static Queue reverse(Queue q ,Queue temp){
        Queue newq=new Queue();
        char c=' ';
        if(q.isempty())
            return temp;
        else{
       while(!q.isempty()){
           c=q.dequeue();
           if(!q.isempty())
               newq.enqueue(c);
       }
         temp.enqueue(c);}
         return reverse(newq,temp);
                 
}
    
}

