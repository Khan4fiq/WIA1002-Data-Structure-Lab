/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question1;

import java.util.LinkedList;

/**
 *
 * @author wic180039
 */
public class Queue {
    LinkedList Queue=new LinkedList<>();
    int size=0;

    public Queue() {
    }
    
    public void enqueue(char e){
        Queue.addLast(e);
        size++;
    }
    
    public char dequeue(){
        char c=(char)Queue.getFirst();
        Queue.removeFirst();
        size--;
        return c;
    }
    
    public boolean isempty(){
        if(Queue.isEmpty())
            return true;
        else
            return false;
    }
    
}
